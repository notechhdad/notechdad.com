PBZ BENCH 1.4.1 — unofficial benchmark tool for Phantom Blade Zero
=====================================================================
Made by No Tech Dad · https://www.notechdad.com · https://www.youtube.com/@no_tech-dad
Free to use. Official download: https://www.notechdad.com/pbz-bench.html

PLEASE READ FIRST
  - PBZ Bench is an unofficial, fan-made tool. It is not affiliated with, endorsed by or supported by S-GAME
    (the developer of Phantom Blade Zero), Valve, Intel, NVIDIA or AMD, so please don't contact them about it.
  - It is provided "as is", without any warranty, and you use it at your own risk. Full terms: LICENSE.txt.
  - While it runs it changes the game's settings file (backed up first, put back afterwards) and, only if you
    turn that option on, your save games. See WHAT IT CHANGES ON YOUR PC.
  - It needs administrator rights and isn't code-signed, so Windows will ask and may warn you. See INSTALL.

WHAT IT DOES
Phantom Blade Zero has no built-in benchmark, so this does what Black Myth: Wukong's
benchmark tool does, but on the real game:
  1. Writes the graphics settings you pick into the game's settings file
  2. Launches the game through Steam
  3. Captures every frame with Intel PresentMon while a fixed route plays
  4. Closes the game, checks the game kept your settings, and puts YOUR own settings back
  5. Shows Avg FPS, 1% / 0.2% / 0.1% lows, frame-time graph, GPU/CPU telemetry — and keeps every run
  6. Writes one row per configuration for your workbook (Results\sheet_summary.csv), lows pooled over all passes

WHAT IT CHANGES ON YOUR PC
  Nothing in the game install is modified, and PBZ Bench never reads or changes the game's memory.
  Only these are touched, and both are backed up first:
    %LOCALAPPDATA%\ProjectPBZ\Saved\Config\Windows\GameUserSettings.ini   the game's settings file
    ...\steamapps\common\PBZ\ProjectPBZ\Saved\SaveGames                   only with Setup → Start position lock
  The untouched first copy of your settings is kept as Backups\GameUserSettings_ORIGINAL.ini, and
  Setup → "Restore ORIGINAL (first run)" puts it back at any time.
  Recorded routes replay keyboard and mouse input, and only while the game is the foreground window.
  Everything PBZ Bench creates stays in its own folder: Results, Backups, Presets, Routes, Exports,
  config.json and PBZBench.log. It installs nothing else.

PRIVACY
  PBZ Bench sends nothing over the internet: no telemetry, no accounts, no update check.
  The only network connection it can make is to OBS (Setup → OBS recording, off by default),
  at the address you type in.
  Saved runs record your PC's hardware and drivers and the computer name (or the device name you set),
  and the log shows folder paths that include your Windows user name. Check before you share result
  files or an Export zip. The Export zip never includes config.json.

INSTALL
  1. Unzip the whole "PBZ Bench 1.4.1" folder somewhere you can write to, e.g. Documents\PBZ Bench
     or C:\PBZ Bench. Not Program Files: PBZ Bench saves its results next to PBZBench.exe.
  2. Keep the tools folder next to PBZBench.exe. It holds Intel PresentMon, which captures the frames.
  3. Double-click PBZBench.exe and choose Yes on the administrator prompt.
     Because PBZ Bench isn't code-signed, Windows SmartScreen may say "Windows protected your PC".
     Only go ahead if you downloaded it from notechdad.com and the SHA-256 matches the one on the
     download page (PowerShell: Get-FileHash .\PBZBench.exe). Then choose More info → Run anyway.
  Updating: unzip the new version over the old folder. Your Results, Presets, Routes, branding,
  Backups and config.json aren't in the download, so they stay as they are.
  Uninstalling: if you want the game's settings exactly as they were before your first run, use
  Setup → "Restore ORIGINAL (first run)". Then delete the folder.

REQUIREMENTS
  Windows 10/11 x64 (uses the built-in .NET Framework 4.8 — nothing to install)
  Runs as administrator (PresentMon needs it to read frame timings) — Windows will ask.
  Steam running. Quit the game before starting a benchmark.

QUICK START (first run)
  1. Double-click PBZBench.exe → Yes on the admin prompt.
  2. Benchmark page: pick Quality Preset, Ray Tracing, Super Resolution Mode, display options.
     "Set in the game's menu" = upscaler method / frame generation / Reflex. The game stores
     these in an encrypted save, so set them in-game once and match them here (they're recorded).
     Native resolution (no upscaling) = Super Resolution Method TSR + Super Resolution Mode "Native (100%) / DLAA".
  3. Route = Manual, Duration = 60, Start trigger = Hotkey, Passes = 3 — or pick a preset (Benchmark → Presets),
     which sets all of it in one go.
  4. START BENCHMARK. The game launches. Load in, walk to your start spot, press F9
     (controller: hold L3 + R3 until the beep, then let go). Beep = capture started. Play your route.
     Second beep = done. F10 (controller: keep holding L3 + R3 for 3 s) aborts at any time.
  5. The game closes, your settings are restored, and Results opens.

REPEATABLE RUNS (closest to Wukong's fixed fly-through)
  Setup → Routes → "Record new route (F9)": launch the game yourself, stand at the start spot,
  F9, walk/turn 30-90 s of calm traversal (no combat, no menus), F9. Keyboard + mouse only.
  Then choose "Recorded: <name>" as the Route — every run replays your exact input timing.
  Add Setup → Start position lock (restores the same save before every run) so each run
  starts on the same spot. Your real saves are backed up first and put back afterwards.
  Built-in alternatives without recording: "Camera pan" and "Walk + pan".

UNATTENDED / BATCH
  Setup → Boot sequence presses through the title screen (wait / key ENTER / ...).
  Calibrate the waits once with your PC. Then Benchmark → Start trigger = Auto.
  Batch page: tick presets × ray tracing × upscaler modes (× resolutions), passes, order.
  "Interleaved" order (A B C, A B C) spreads heat-soak across configs — best for videos.

ON-SCREEN OVERLAY  (Setup → On-screen overlay & launch)
  Status panel (on by default): "Press F9 to start", the countdown and the result appear over
  the game. It disappears a full second before the capture starts, so it can't affect the frames.
  Live overlay (off by default): live FPS, frame time, running avg / 1% low and a 5-second
  frame-time graph during the capture. It is a window on top of the game, which can switch the
  game from independent flip to composed presentation and cost a little performance — every run
  made with it is flagged "live overlay ON". Works best in Borderless.

OBS AUTO-RECORD  (Setup → OBS recording)
  OBS → Tools → WebSocket Server Settings → Enable server, copy the password into PBZ Bench.
  Each capture starts OBS recording at the lead-in (pre-roll), adds chapter markers at capture
  start/end (OBS 30.2+ Hybrid MP4), and stops after the post-roll. The clip path and the offset
  where the measured window begins inside the clip are saved with the run ("Open clip" button,
  obs_clip / obs_clip_offset_s columns). OBS can run on your capture PC: enter its IP.
  If OBS was already recording, PBZ Bench leaves it alone. Runs recorded with OBS are marked.
  The password is stored encrypted for your Windows user (re-enter it on another PC).

STEAM LAUNCH CONFIRMATION
  Before launching through Steam the tool asks first (Setup → "Ask before launching the game
  through Steam"). If your account is in use on another device, let that finish first — Steam
  would otherwise ask to take the session over.

SETTINGS VERIFICATION
  On a clean exit the game rewrites its settings file. PBZ Bench reads it back:
    "Verified"            the game rewrote the file and kept exactly what was written
    "Verified — ray tracing from the game's menu"  the game ran its own menu's ray tracing (its encrypted save wins);
                          the run is labelled with it (details list both values)
    "Game changed N ..."  the game overrode something (listed in the run's details). For Super Resolution Mode the note
                          says what the number would mean, e.g. "game kept 4 — that's TSR Native (100%) if the game's
                          upscaler is TSR": check the method and mode in the menu, then Results → Rename can record it
    "Unconfirmed"         the game didn't rewrite the file on exit, ran an FSR/XeSS mode PBZ Bench can't name yet, or was
                          left running after the session (its menu may have changed by the time you quit)
    "Not verified"        the game had to be force-closed
  (In Borderless the resolution isn't checked — UE always stores the desktop size there.)
  A run's label follows the game's ray tracing when the label was made from the settings; a label you typed is kept.
  Super Resolution Mode numbers: DLSS and TSR 0 Ultra Performance … 3 Quality, 4 DLAA / Native (100%);
  FSR and XeSS Quality = 2 (confirmed in the menu on three handhelds). Other FSR/XeSS modes: set them in the game menu.

CAPTURE CHECKS (every run)
  PresentMon is stopped cleanly right after the capture (its session drains and flushes the CSV).
  The kept frames must cover at least 90% of the measured window or the run is rejected as truncated.
  Warnings are saved with the run and shown in Results / all_runs.csv: gaps at the start or end,
  PresentMon "ETW events lost / overflowed presents", fewer than 2,000 frames (the 1% low then rests
  on fewer than 20 frames), frame generation found but set to Off (or set but not found), and passes of one
  configuration that rise, fall or start slow (warm-up or heat; flagged once the session ends).
  The 0.2% and 0.1% lows aren't warned about; each gets a reliability label instead (see LOWS below).

RESULTS
  Results\<date>_<label>\summary.json         all stats, settings (incl. the real values behind "keep"), system info
  Results\<date>_<label>\series.json          per-frame times + telemetry (loaded on demand)
  Results\<date>_<label>\presentmon_log.txt   PresentMon's console output for that run
  Results\<date>_<label>\frames_presentmon.csv raw per-frame PresentMon data
  Results\<date>_<label>\telemetry.csv         1 Hz GPU/CPU/RAM/battery samples
  Results\<date>_<label>\result.png            "Save as image" (YouTube-ready card)
  Results\<date>_<label>\override.json         Results → Rename: device name, label, settings check (display only)
  Results\_warmup\<date>_<label>_warmup\       warm-up passes, kept for reference, never counted
  Exports\PBZBench_<device>_<time>.zip          Results → Export for Claude
  Presets\<name>.json                          your presets (Benchmark → Presets)
  Results\all_runs.csv                         one row per run (every pass)
  Results\sheet_summary.csv                    one row per CONFIGURATION — the one to paste into your workbook.
                                               Rebuilt after every session from all saved runs; "Sheet summary" on
                                               the Results page rebuilds it now and copies it for Excel (Ctrl+V).
                                               If Excel has it open, the update goes to sheet_summary_pending.csv.
  Compare → "Export for sheet"                 the same columns for just the ticked runs (Results\_comparisons).
  Passes are combined only when everything that affects the numbers is identical: settings, upscaler, frame gen,
  Reflex, the route actually played (a recorded route's file, a pan's length and speed), the game build (Steam build
  id — a patch is a different workload), device, CPU, RAM, GPU (an eGPU counts as a different GPU), driver, display
  mode (refresh rate), power
  source and mode (battery vs plugged in), and the metric basis. Flagged runs (settings changed, live overlay, OBS
  recording — including OBS that was already recording) are kept apart.
  all_runs.csv has one row per run: a run saved again (e.g. once its settings check is known) replaces its row.
  An all_runs.csv from an older version (different columns) is kept as all_runs_old_<time>.csv and a new one is
  rebuilt from the run folders, so every row has the same columns. Older runs get their 0.2% low from their
  saved frames.

SHEET SUMMARY COLUMNS (one row per configuration)
  config_id                 8-character id of the configuration — stable, handy for lookups in Excel
  game_build                Steam build id of the game when the passes ran
  avg_fps                   mean of the passes; avg_fps_min / max / spread_pct show how repeatable they were
  p1 / p02 / p01_low_fps    lows from the POOLED frames of every pass (all frame times together)
  low1 / low02 / low01_avg  "avg of worst" versions, also pooled
  *_tail_frames             frames beyond each percentile in the pool; *_reliability = OK / rough / unreliable
  p1_low_spread_pct         how far the passes' own 1% lows were apart
  lows_basis                "pooled frames of N passes" (or "mean of passes" if a pass has no frame data — then the
                            reliability is that of the weakest pass)
  spikes / hitches          totals over the passes and per minute of capture
  gpu_power_avg_w, fps_per_gpu_w, battery_avg_w, fps_per_system_w, temps, clocks, VRAM peak, CPU load
  settings_verified         e.g. "3/3 Verified" or "2/3 Verified · 1 Unconfirmed"
  warnings, live_overlay, obs, first_run, last_run, folders
  rendered_fps              real frames per second behind a frame-generation result (rendered_fps_source: measured / estimated)
  pass_trend                "rising: 33.5 → 36.6 → 37.5 fps (+11%)", "falling: …" or "first slow: …" — empty when steady

METRIC DEFINITIONS (match PresentMon unless noted)
  Avg FPS        frames ÷ capture time (1000 / mean frame time)
  1% Low (P1)    1000 / 99th-percentile frame time, linear interpolation — PresentMon's 1% low
  0.2% Low       1000 / 99.8th-percentile frame time
  0.1% Low       1000 / 99.9th-percentile frame time
  avg of worst   1000 / mean of the slowest 1% (or 0.2% / 0.1%) of frames — CapFrameX-style low
  Displayed FPS  from MsBetweenDisplayChange — what actually reached the screen (+ its own 1% / 0.1% low)
  Frame gen      Found from any of: presents in pairs ~0.4 ms apart (DLSS FG), present intervals that alternate
                 between two values (FSR / XeSS FG: alternation 1.8+ vs about 0.2 without; when the setting says Off
                 the GPU work must alternate too and V-Sync must be off), frames without a game simulation start
                 (Reflex markers: generated frames have none), repeated display rows (driver FG such as AFMF), frame
                 types. When frame generation is on (found, or set in the run), the headline FPS / lows / stutter are
                 measured on DISPLAYED frames (MsBetweenDisplayChange) — present timing no longer matches what you
                 see — and the presented numbers are kept alongside. A run labelled "Frame gen: Off" is relabelled.
  Rendered FPS   the real frames behind a frame-generation result: measured from Reflex markers (and their 1% low)
                 or from the game's own presents (driver FG); otherwise estimated as on-screen ÷ 2 (÷ 3, ÷ 4 for MFG).
  Min / Max FPS  slowest single frame / fastest 1% (a single fastest frame is meaningless with tearing or FG)
  Spikes         frames > 2× the rolling median of the previous 30 frames (and ≥ 4 ms slower); also per minute
  Hitches        frames > 50 ms
  GPU busy       PresentMon GPU-busy ÷ frame time (≥ 90% → GPU-limited). Limiter / V-Sync / Reflex sleep count
                 as CPU busy in PresentMon, so capped runs are labelled "Frame-capped" instead of CPU-limited
  PC latency     PresentMon --track_pc_latency (Reflex games)
  Battery draw   whole-system watts from the battery when unplugged (handhelds)

LOWS: HOW MANY FRAMES THEY NEED
  A low is only as steady as the number of frames beyond its percentile ("tail frames": the frames it rests on).
  About 20 tail frames make it repeatable from run to run:
     ≥ 20  OK          5–19  rough          < 5  unreliable
  That takes about 2,000 frames for the 1% low, 10,000 for the 0.2% low and 20,000 for the 0.1% low.
  At 146 fps a 60 s pass has ~8,800 frames: 1% OK, 0.2% rough (18). Three passes pooled: 0.2% OK (53), 0.1% OK (27).
  At 40 fps on a handheld, 3 × 60 s pooled gives 7,200 frames: 1% OK, 0.2% rough (15) — use 90–120 s passes there.
  The Results tile shows the tail count and turns amber (rough) or grey (unreliable).

HANDHELDS
  Copy the whole PBZ Bench folder to the handheld and run it there; paths are re-detected.
  Pick a preset (the built-in passes use the handheld's own desktop resolution), and Results → Rename → "Use the
  device name for new runs" names the device once (e.g. "X2 Mini Pro · AI Max+ 388 · 55 W").
  Copy the handheld's Results\<run> folders back into the PC's Results folder to compare devices, or use
  Results → Export for Claude and attach the zip in a chat.
  Controller (Setup → Controller): hold L3 + R3 until the beep (1 s), then let go = start (like F9).
  Keep holding for 3 s = abort (like F10). A short tap does nothing, and because a run only starts when you let go,
  holding to abort can never start one. At the prompt the overlay says "Let go to start" while you hold; if the
  prompt appears while you're already holding, you get 2 more seconds to let go before it counts as an abort.
  Works with XInput pads (Legion Go, ROG Ally, MSI Claw built-in controllers) while the game has focus.
  "Test controller" shows what it sees.
  Other combinations: LB + RB + View, or View + Menu (Menu may open the game's pause menu). Or map a back button
  to F9 / F10 in Legion Space / Armoury Crate instead.
  Battery runs, plugged-in runs and eGPU runs are kept apart automatically in Compare and the sheet summary.

PERSONALIZE  (Setup → Branding)
  Set your own name, handle and logo here before you share images: out of the box they show No Tech Dad's.
  Channel name and handle (default No Tech Dad · @No_Tech-Dad) and your logo: "Choose logo…" copies it to
  branding\channel_logo.png next to PBZBench.exe (or drop a file with that name there yourself).
  They appear in the header, on "Save as image" result and comparison cards (logo + youtube.com/<handle>) and on
  the in-game status panel (prompt / countdown / result, never during a capture). Untick "Show my logo..." to hide
  them on images and the overlay. Without a logo, your initials are shown. The ink-wash artwork is drawn by the
  tool itself; no game artwork is included.

GOOD TO KNOW
  F9 / F10 (and the controller combination) are only watched while a benchmark or recording is active.
  Routes only send input while the game is the foreground app; if it loses focus for more than
  0.3 s the route stops and all keys are released (nothing is typed into other apps).
  If all_runs.csv is open in Excel, new rows wait in all_runs_pending.csv and are merged later.
  Keep overlays (Steam, NVIDIA, RTSS) consistent between runs — they change Present mode.
  Windows Defender/SmartScreen may warn about an unsigned app that records/sends input.
  Settings backups: Backups\GameUserSettings_ORIGINAL.ini is the untouched first copy.
  If PBZ Bench is closed or crashes before restoring, it remembers (Backups\restore_pending.json) and
  offers to restore on the next start; the next session also treats that backup as your real settings.
  Setup → "Restore last session backup" / "Restore ORIGINAL (first run)" work at any time.
  Route replay is deliberately light (≈3% of one core, normal priority) so it doesn't skew CPU-bound scenes.

SUPPORT, UPDATES AND FEEDBACK
  Download page, instructions and new versions: https://www.notechdad.com/pbz-bench.html
  Bug reports and ideas: https://www.notechdad.com/feedback.html
  For a bug report, Results → Export for Claude makes a zip of the day's runs and the log that you can attach.
  What changed in each version: CHANGELOG.txt

CREDITS
  Frame capture: Intel PresentMon 2.6.0 (MIT licence, tools\PresentMon-LICENSE.txt).
  Unofficial fan tool — not affiliated with S-GAME.
