Put your channel logo here as channel_logo.png (PNG, square works best; JPG is fine too).
Or use PBZ Bench → Setup → Branding → Choose logo…, which copies it here for you.
It shows in the header, on saved result / comparison images and on the in-game status panel.
